This Assignment is about a chat user interface built using HTML, CSS and JavaScript.It simulates a messaging application with user and AI response.

Features:
Welcome Screen with suggestion cards.
Chat bubbles for user and AI response.
Animated typing Indicator
Auto-resizing input box
send button functionality
sidebar with chat history.
Clean and respionsive layout.

Technologies used are HTML, CSS(Bootstrap) and Javascript.

 <!-- How to Run  -->
 Open the  project folder
 open index.html in a browser like Microsoft Edge, Google Chrome.

<!-- Output -->
The Chat UI displays a Interface with sidebar , message area, and  input field.

