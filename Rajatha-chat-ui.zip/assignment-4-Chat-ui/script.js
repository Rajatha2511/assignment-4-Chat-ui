function sendMessage() {
    let input = document.getElementById("message-input");
    let message = input.value;

    if (message.trim() === "") return;

    document.getElementById("welcome-section").style.display="none";

    let chatBox = document.getElementById("chat-box");

    let messageDiv = document.createElement("div");
    messageDiv.className = "user-message";
    messageDiv.innerText = message;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
    input.value = "";

    let typingDiv=document.createElement("div");
    typingDiv.className = "typing-indicator";
    typingDiv.innerHTML = `<span></span><span></span><span></span>`;
    chatBox.appendChild(typingDiv);
    
    chatBox.scrollTop = chatBox.scrollHeight;
     setTimeout(() => {
        // Remove typing indicator
        chatBox.removeChild(typingDiv);

        // 🤖 AI message
        let aiMessage = document.createElement("div");
        aiMessage.className = "ai-message";
       aiMessage.innerText = "How can I help you?";

        chatBox.appendChild(aiMessage);
        chatBox.scrollTop = chatBox.scrollHeight;

    }, 1500);
}
let inputBox = document.getElementById("message-input");

inputBox.addEventListener("input", function () {
    this.style.height = "auto";
    this.style.height = this.scrollHeight + "px";
});












